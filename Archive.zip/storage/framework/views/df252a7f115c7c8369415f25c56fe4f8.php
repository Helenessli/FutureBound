<!DOCTYPE html>
<html>
<head>
    <title>Form Submission</title>
</head>
<body>
    <h1>Form Submission Details</h1>
    <p><strong>Name:</strong> <?php echo e($dataReceived['name']); ?></p>
    <p><strong>Amount:</strong> <?php echo e($dataReceived['amount']); ?></p>
    <p><strong>Criteria:</strong> <?php echo e($dataReceived['criteria']); ?></p>
    <p><strong>Deadline:</strong> <?php echo e($dataReceived['deadline']); ?></p>
    <p><strong>Url:</strong> <?php echo e($dataReceived['url']); ?></p>
</body>
</html><?php /**PATH /Users/helenli/websites/Futurebound/resources/views/email_template.blade.php ENDPATH**/ ?>