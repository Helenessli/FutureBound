<?php $__env->startSection('section'); ?>

<div class="heading2">
   <p class="tiny">Scholarships</p>
   <h2>Scholarships</h2>
   <p class="description1">Find your next scholarship through our handpicked database designed for graduating <span style="color: #652dcb; font-weight: 600;">high school</span> students.</p>
   <form action="<?php echo e(route('scholarships')); ?>" method="GET">

      <!-- Search box -->
      <div class="boxContainer">
         <div class="elementsContainer">
            <div class="material-icons">
               search
            </div>
            <input type="text" name="search" placeholder="Scholarship name or keyword" value="<?php echo e(request()->query('search')); ?>">
            <button type="submit" class="btn btn-search">Search</button>
         </div>
      </div>


      <!-- Tags  filter -->
      <div class="allfiltercontainer">
         <div class="tagsfiltercontainer">
            <div class="container">
               <div class="select-btn">
                  <span class="btn-text">Filter by Category</span>
                  <span class="arrow-dwn">
                     <i class="fa-solid fa-chevron-down"></i>
                  </span>
               </div>
               <ul class="list-items">
                  <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="item">
                     <input class="checkbox" type="checkbox" name="tags[]" value="<?php echo e($tag->id); ?>" <?php if(in_array($tag->id, request('tags', []))): echo 'checked'; endif; ?>>
                     <span class="item-text"><?php echo e($tag->name); ?> </span>
                  </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </ul>

            </div>
         </div>

         <!-- deadline filter-->
         <div class="deadlinefiltercontainer">
            <div>
               <label class="deadlinelabel">Deadline:</label>
               <input class="deadlineinputs" type="date" name="start_deadline" class="form-control" value=<?php echo e(request('start_deadline', '')); ?>>
            </div>

            <div>
               <label class="deadlinelabel">to</label>
               <input class="deadlineinputs" type="date" name="end_deadline" class="form-control" value=<?php echo e(request('end_deadline', '')); ?>>
            </div>
         </div>
      </div>
   </form>
</div>
<main>

   <div class="scholarships">
      <p class="numScholarships"><?php echo e($totalScholarships); ?> scholarships</p>
      <div class="scholarship-list">
      <?php $__empty_1 = true; $__currentLoopData = $scholarships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scholarship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <article class="articlescholarships">
         <a href="/scholarships/<?php echo e($scholarship->id); ?>">
            <div class="cell">
               <h1 class="scholarships-h1">
                     <?php echo e($scholarship->name); ?>

               </h1>

               <div class="scholarship-icons">
                  <div class="iconandinfo">
                     <span class="material-symbols-outlined">
                        event
                     </span>
                     <span class="scholarshiplistinfo1"><?php echo e($scholarship->deadline); ?></span>
                  </div>

                  <div class="iconandinfo2">
                     <span class="material-symbols-outlined">
                        attach_money
                     </span>
                     <span class="scholarshiplistinfo"><?php echo e($scholarship->amount); ?></span>
                  </div>
               </div>

               <div>
                  <?php $__currentLoopData = $scholarship->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <button class="pill" type="button">
                     <span class="tagname"><?php echo e($tag->name); ?></span>
                  </button>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>

               <br>

               <span class="btn2">
                  Learn More
               <span>
            </div>
         </a>
      </article>


      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <div class="empty">No scholarships found.</div>
      <?php endif; ?>
      </div>
   </div>
   <div class="pagination">
   <?php echo e($scholarships->links()); ?>

   </div>
   <!-- Javascript for tags filter-->
   <script src="<?php echo e(asset('script.js')); ?>"></script>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/helenli/websites/Futurebound/resources/views/scholarships.blade.php ENDPATH**/ ?>