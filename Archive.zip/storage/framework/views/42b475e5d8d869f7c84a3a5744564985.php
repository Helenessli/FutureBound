<!DOCTYPE html>
<html>
<head>
    <title>Form Submission</title>
</head>
<body>
    <h1>Form Submission Details</h1>
    <p><strong>Name:</strong> <?php echo e($data['name']); ?></p>
    <p><strong>Amount:</strong> <?php echo e($data['amount']); ?></p>
    <p><strong>Criteria:</strong> <?php echo e($data['criteria']); ?></p>
    <p><strong>Deadline:</strong> <?php echo e($data['deadline']); ?></p>
    <p><strong>Url:</strong> <?php echo e($data['url']); ?></p>
</body>
</html>
<?php /**PATH /Users/helenli/websites/Futurebound/resources/views/emails/form_submission.blade.php ENDPATH**/ ?>