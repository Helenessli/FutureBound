<!DOCTYPE html>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<head>
    <title>Scholarships</title>
    <link rel="stylesheet" href="/app.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
    <header class="header">
        <a href="/" class="logo">Logo.</a>
        <nav class="navbar">
            <ul class="nav__links">
                <a href="/" style="--i:1;">Explore Scholarships</a>
                <a href="/add" style="--i:2;">Add Scholarship</a>
            </ul>
        </nav>
        
        <div class="social-media">
            <i class='bx bxl-twitter'></i>
            <i class='bx bxl-facebook'></i>
            <i class='bx bxl-instagram'></i>
        </div>
        <br>
        <!-- Display the search bar on the scholarships page only -->
        <form action="<?php echo e(route('scholarships')); ?>" method="GET">
        <div class="boxContainer">
                <table class="elementsContainer">
                <tr>
                        <td class="td1">
                                <input type="text" name="search" placeholder="Search Scholarships" value = "<?php echo e(request()->query('search')); ?>">
                        </td>
                        <td class="td2">
                        <div class="material-icons">
                                search
                        </div>
                        </td>
                </tr>
                </table>
        </div>
        </form>
    </header>

    <!-- Display the main content -->
    <?php echo $__env->yieldContent('section'); ?>

</html>
<?php /**PATH /Users/helenli/websites/Futurebound/resources/views/layout/scholarships_layout.blade.php ENDPATH**/ ?>