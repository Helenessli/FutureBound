<?php $__env->startSection('section'); ?>
<main>
        <article>
                <div class="cell2">
                        <a href="<?= $scholarship->url; ?>">
                                <h1 class="scholarships-h1"><?= $scholarship->name; ?></h1>
                        </a>
                        <?php $__currentLoopData = $scholarship->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button class="pill2" type="button">
                                <?php echo e($tag->name); ?>

                        </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="scholarshipinfo">
                                <div>
                                        Deadline:&nbsp; <?= $scholarship->deadline; ?>
                                </div>
                                <div>
                                        Amount: &nbsp;$<?= $scholarship->amount; ?>
                                </div>
                                <div>
                                        Criteria:&nbsp; <?= $scholarship->criteria; ?>
                                </div>
                        </div>
                        <br>
                        <a href="<?= $scholarship->url; ?>" class="btn">
                                Apply
                        </a>
                        <br>
                </div>
        </article>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/helenli/websites/Futurebound/resources/views/scholarship.blade.php ENDPATH**/ ?>